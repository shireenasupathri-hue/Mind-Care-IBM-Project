"""
MindCare — Agentic AI for Mental Health Awareness & Suicide Prevention
IBM Hackathon | Problem Statement No. 2

5-Agent System orchestrated via IBM Langflow / IBM Orchestrate
Powered by IBM Granite Models

Tech Stack:
  - IBM Langflow (workflow orchestration, RAG pipeline)
  - IBM Orchestrate (multi-agent coordination)
  - IBM Granite (granite-13b-chat-v2 via IBM watsonx.ai)

DISCLAIMER: This system is for EDUCATIONAL AWARENESS ONLY.
            No diagnosis. No therapy. No stored data.
            Always encourage professional help.
            Crisis: KIRAN 1800-599-0019
"""

import json
import os
import datetime
import re
from pathlib import Path

# ─────────────────────────────────────────────────────────────────────────────
# Load Knowledge Base
# ─────────────────────────────────────────────────────────────────────────────
KB_PATH = Path(__file__).parent / "knowledge_base.json"

def load_knowledge_base():
    if KB_PATH.exists():
        with open(KB_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

KNOWLEDGE_BASE = load_knowledge_base()


# ─────────────────────────────────────────────────────────────────────────────
# Agent 1: AwarenessAgent
# IBM Granite — Promote Awareness & Education
# ─────────────────────────────────────────────────────────────────────────────
class AwarenessAgent:
    """
    IBM Langflow Node: AwarenessAgent
    Model: IBM Granite granite-13b-chat-v2 (via watsonx.ai)
    Purpose: Retrieve mental health awareness content from knowledge base.
    """

    TOPICS = {
        "mindfulness": "mindfulness",
        "coping":      "coping_strategies",
        "selfcare":    "self_care",
        "self-care":   "self_care",
        "distress":    "distress_education",
        "all":         None,
    }

    def get_resources(self, topic: str = "all") -> dict:
        """
        Retrieve awareness resources for a given topic from the knowledge base.

        Args:
            topic: One of 'mindfulness', 'coping', 'selfcare', 'distress', 'all'

        Returns:
            dict with topic entries and IBM Granite simulated response context
        """
        kb_key = self.TOPICS.get(topic.lower(), None)

        if kb_key and kb_key in KNOWLEDGE_BASE:
            entries = KNOWLEDGE_BASE[kb_key]
        else:
            # Return all sections
            entries = {}
            for k, v in KNOWLEDGE_BASE.items():
                if isinstance(v, list):
                    entries[k] = v

        # IBM Granite prompt context (simulated for local run)
        prompt = (
            f"[IBM Granite granite-13b-chat-v2] "
            f"You are a mental health awareness assistant. "
            f"Provide educational information about: {topic}. "
            f"Use only the provided knowledge base. Do not diagnose. Be empathetic."
        )

        return {
            "agent": "AwarenessAgent",
            "model": "IBM Granite granite-13b-chat-v2",
            "topic": topic,
            "prompt_context": prompt,
            "resources": entries,
            "disclaimer": EthicsAgent.disclaimer(),
        }

    def format_output(self, topic: str = "all") -> str:
        result = self.get_resources(topic)
        lines = [f"\n{'='*60}", "AGENT 1: AwarenessAgent (IBM Granite)", f"Topic: {topic.upper()}", f"{'='*60}"]
        resources = result["resources"]
        if isinstance(resources, dict):
            for section, items in resources.items():
                lines.append(f"\n[ {section.replace('_', ' ').title()} ]")
                if isinstance(items, list):
                    for item in items:
                        lines.append(f"  • {item.get('title','')}: {item.get('body','')}")
        elif isinstance(resources, list):
            for item in resources:
                lines.append(f"  • {item.get('title','')}: {item.get('body','')}")
        lines.append(f"\n{result['disclaimer']}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Agent 2: EarlyDetectionRAGAgent
# IBM Langflow RAG Pipeline — Enable Early Detection
# ─────────────────────────────────────────────────────────────────────────────
class EarlyDetectionRAGAgent:
    """
    IBM Langflow Node: EarlyDetectionRAGAgent
    Model: IBM Granite Embeddings + granite-13b-chat-v2
    RAG Pipeline: knowledge_base.json → Vector Search → Retrieval → Augmented Generation
    Purpose: Educational awareness from journal text. NO diagnosis.
    """

    # Flat knowledge base list for RAG simulation
    knowledge_base: list = []

    def __init__(self):
        # Flatten all KB entries into a single retrievable list
        for section, items in KNOWLEDGE_BASE.items():
            if isinstance(items, list):
                for item in items:
                    self.knowledge_base.append({
                        "section": section,
                        "id":      item.get("id", ""),
                        "title":   item.get("title", ""),
                        "body":    item.get("body", ""),
                        "tags":    item.get("tags", []),
                    })

    def _rag_retrieve(self, query: str, top_k: int = 3) -> list:
        """
        Simulated IBM Langflow RAG retrieval.
        In production: IBM Granite Embeddings → Milvus/Chroma vector store → cosine similarity.
        Here: keyword-based retrieval from flattened knowledge base.
        """
        query_lower = query.lower()
        scored = []
        keywords = re.findall(r'\w+', query_lower)

        for entry in self.knowledge_base:
            score = 0
            text = (entry["title"] + " " + entry["body"] + " " + " ".join(entry["tags"])).lower()
            for kw in keywords:
                if len(kw) > 3 and kw in text:
                    score += 1
            if score > 0:
                scored.append((score, entry))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:top_k]]

    def detect_signals(self, journal: str) -> dict:
        """
        Detect educational stress awareness signals from journal text using RAG.

        Args:
            journal: User's free-form journal text

        Returns:
            dict with RAG results for education ONLY (no diagnosis)
        """
        if not journal or len(journal.strip()) < 10:
            return {
                "agent": "EarlyDetectionRAGAgent",
                "model": "IBM Granite Embeddings + granite-13b-chat-v2",
                "status": "no_input",
                "message": "No journal text provided for RAG analysis.",
                "rag_results": [],
                "disclaimer": EthicsAgent.disclaimer(),
            }

        retrieved = self._rag_retrieve(journal)

        # Signal pattern detection for educational context
        signal_map = {
            r"sleep|insomnia|awake|tired|exhausted|fatigue": "Sleep Changes",
            r"alone|lonely|isolat|withdraw|nobody|no one":   "Social Withdrawal",
            r"hopeless|worthless|pointless|give up|no point": "Hopelessness Indicators",
            r"stress|overwhelm|pressure|too much|burden":     "Stress Indicators",
            r"sad|depress|unhappy|miserable|down|low mood":   "Low Mood Indicators",
            r"eat|appetite|food|hunger|weight":               "Appetite Changes",
        }
        detected_signals = []
        lower = journal.lower()
        for pattern, label in signal_map.items():
            if re.search(pattern, lower):
                detected_signals.append(label)

        return {
            "agent":            "EarlyDetectionRAGAgent",
            "model":            "IBM Granite Embeddings + granite-13b-chat-v2",
            "rag_pipeline":     "IBM Langflow RAG → knowledge_base.json → IBM Granite Embedding → Retrieval",
            "journal_length":   len(journal),
            "signals_detected": detected_signals,
            "rag_results":      retrieved,
            "educational_note": "These are general awareness topics relevant to your journal. NOT a clinical assessment.",
            "disclaimer":       EthicsAgent.disclaimer(),
        }


# ─────────────────────────────────────────────────────────────────────────────
# Agent 3: EmpatheticSupportAgent
# IBM Granite — Provide Empathetic Support
# ─────────────────────────────────────────────────────────────────────────────
class EmpatheticSupportAgent:
    """
    IBM Langflow Node: EmpatheticSupportAgent
    Model: IBM Granite granite-13b-chat-v2
    Purpose: Active listening, empathetic responses. NOT therapy.
    """

    RESPONSE_TEMPLATES = {
        "sad": [
            "Thank you for sharing that with me. It takes courage to acknowledge sadness. You are not alone in feeling this way. Have you been able to talk to someone you trust?",
            "I hear you. Sadness is a valid and human experience. Acknowledging it, as you have, is the first step. Please consider reaching out to a trusted friend or KIRAN 1800-599-0019.",
        ],
        "anxious": [
            "Thank you for opening up. Anxiety can feel overwhelming, but naming it is the first step. Try breathing slowly: inhale 4 counts, hold 4, exhale 4. You are safe right now.",
            "I understand. What you're feeling is real and valid. Many people experience anxiety. A small grounding exercise — 5 things you see, 4 you touch — can help bring you back to the present.",
        ],
        "lonely": [
            "I'm glad you shared this. Loneliness is painful. You deserve connection. Is there one person — a friend, family member, or counsellor — you could reach out to today?",
            "Thank you for trusting me with this. Loneliness often feels permanent, but it isn't. Even one small connection can begin to shift it. You matter.",
        ],
        "stressed": [
            "It sounds like you're carrying a lot right now. That is genuinely hard. Let's take one thing at a time. What feels most pressing? Remember: it's okay to ask for help.",
            "Thank you for sharing. Stress accumulates quietly. Identifying it, as you have, is meaningful. Have you tried a short walk or brief journaling today?",
        ],
        "hopeless": [
            "I hear you, and I want you to know your feelings matter. When hope feels distant, that is often a sign that support is needed — not that things cannot improve. Please call KIRAN 1800-599-0019 to speak with a trained professional. You are not alone.",
            "Thank you for being honest. Feeling hopeless is painful, and I take what you're sharing seriously. Please reach out to a trusted person or call Tele-MANAS 14416 right now.",
        ],
        "default": [
            "Thank you for sharing with me. It takes real courage to express how you feel. I am here to listen. Tell me more about what has been on your mind.",
            "I appreciate you opening up. Whatever you are going through, support is available. You deserve to feel better, and reaching out is a brave step.",
        ],
    }

    def get_empathy_response(self, feeling: str) -> dict:
        """
        Generate an empathetic response based on expressed feeling.

        Args:
            feeling: User's expressed feeling or message

        Returns:
            dict with IBM Granite empathetic response + disclaimer
        """
        lower = feeling.lower()
        key = "default"
        if re.search(r"sad|cry|unhappy|depress", lower):
            key = "sad"
        elif re.search(r"anxious|anxiety|panic|worry|fear|scared", lower):
            key = "anxious"
        elif re.search(r"lonely|alone|isolated|no one|nobody", lower):
            key = "lonely"
        elif re.search(r"stress|overwhelm|pressure|too much|burden", lower):
            key = "stressed"
        elif re.search(r"hopeless|worthless|no point|give up|die|end it|suicid", lower):
            key = "hopeless"

        import random
        response = random.choice(self.RESPONSE_TEMPLATES[key])

        return {
            "agent":     "EmpatheticSupportAgent",
            "model":     "IBM Granite granite-13b-chat-v2",
            "feeling":   feeling,
            "response":  response,
            "disclaimer": (
                "I am an AI assistant, not a human counsellor. I am NOT a substitute "
                "for professional mental health advice, diagnosis, or treatment. "
                "For personal concerns, please consult a qualified professional. "
                "In crisis: KIRAN 1800-599-0019."
            ),
        }


# ─────────────────────────────────────────────────────────────────────────────
# Agent 4: PredictPreventAgent
# IBM Granite — Predict & Prevent Risks
# ─────────────────────────────────────────────────────────────────────────────
class PredictPreventAgent:
    """
    IBM Langflow Node: PredictPreventAgent
    Model: IBM Granite granite-13b-chat-v2
    Purpose: Stress awareness forecast + preventive strategies. NOT clinical risk assessment.
    """

    def predict(self, mood_score: int, journal: str = "") -> dict:
        """
        Generate a stress awareness forecast and preventive strategies.

        Args:
            mood_score: Self-reported mood 1-10
            journal:    Optional journal text for context

        Returns:
            dict with forecast level, preventive strategies, and alert if needed
        """
        journal_len = len(journal.strip()) if journal else 0

        # Stress awareness level determination (awareness only, not clinical)
        if mood_score >= 7 and journal_len < 200:
            level = "Low Stress Awareness Level"
            emoji = "🟢"
            forecast = (
                "Your self-reported mood and journal patterns suggest a generally positive state. "
                "Continue your current wellness practices and maintain social connections."
            )
            strategies = [
                "Maintain your sleep schedule (7-9 hours)",
                "Keep up with social connections",
                "Practice gratitude journaling weekly",
                "Continue physical activity (150 min/week WHO guideline)",
                "Periodic mindfulness check-ins",
            ]
            alert = False

        elif mood_score >= 4:
            level = "Moderate Stress Awareness Level"
            emoji = "🟡"
            forecast = (
                "Your mood score indicates some stress signals. Proactive self-care "
                "and early support-seeking are recommended."
            )
            strategies = [
                "Try a 10-minute walk today",
                "Practice the 5-4-3-2-1 grounding technique",
                "Reach out to a trusted friend or family member",
                "Reduce screen time before bed",
                "Consider journaling your thoughts for 10 minutes",
                "Ensure regular meals and hydration",
            ]
            alert = False

        else:
            level = "Needs Attention — Support Recommended"
            emoji = "🟠"
            forecast = (
                "Your current mood score suggests elevated stress signals. "
                "This is not a diagnosis, but a gentle signal to reach out for support. "
                "You do not have to face this alone."
            )
            strategies = [
                "Speak with a trusted person today",
                "Call KIRAN 1800-599-0019 for free, confidential support",
                "Practice box breathing: 4-4-4-4",
                "Avoid isolation — connect with someone",
                "Consider speaking with a college counsellor or PHC",
                "If feelings persist, consult a qualified mental health professional",
            ]
            alert = True

        result = {
            "agent":       "PredictPreventAgent",
            "model":       "IBM Granite granite-13b-chat-v2",
            "mood_score":  mood_score,
            "journal_len": journal_len,
            "level":       level,
            "emoji":       emoji,
            "forecast":    forecast,
            "strategies":  strategies,
            "alert":       alert,
            "disclaimer":  (
                "This forecast is based on self-reported data for awareness purposes ONLY. "
                "It is NOT a clinical risk assessment or diagnosis. "
                "Please consult a qualified professional for any health concerns."
            ),
        }
        if alert:
            result["alert_message"] = (
                "If low mood persists, please consider telling a trusted person "
                "or healthcare professional. Seeking help is strength, not weakness. "
                "Call KIRAN 1800-599-0019 (24/7, Free, Multilingual)."
            )
        return result


# ─────────────────────────────────────────────────────────────────────────────
# Agent 5: HumanConnectAgent
# IBM Orchestrate — Connect to Human Support
# ─────────────────────────────────────────────────────────────────────────────
class HumanConnectAgent:
    """
    IBM Orchestrate Node: HumanConnectAgent
    Purpose: Connect users to human support helplines, counsellors, and PHCs.
    """

    NATIONAL_HELPLINES = [
        {"name": "KIRAN Mental Health Helpline",  "number": "1800-599-0019",  "note": "24/7 Free Multilingual, Govt of India"},
        {"name": "Tele-MANAS",                     "number": "14416",           "note": "24/7 Govt of India"},
        {"name": "Vandrevala Foundation",          "number": "1860-2662-345",  "note": "24/7 Crisis Support"},
        {"name": "iCall (TISS Mumbai)",            "number": "9152987821",     "note": "Weekdays 8am-10pm"},
        {"name": "Sneha India Foundation",         "number": "044-24640050",   "note": "24/7 Emotional Support"},
        {"name": "Emergency Services",             "number": "112",             "note": "Police + Ambulance 24/7"},
    ]

    CITY_HELPLINES = {
        "hyderabad":  ["NIMHANS Outreach: 080-46110007", "Roshni (Hyd): 040-66202000", "Govt MH Hospital Erragadda: 040-23268279"],
        "bangalore":  ["NIMHANS: 080-46110007", "Vandrevala: 1860-2662-345", "iCall: 9152987821"],
        "mumbai":     ["iCall TISS: 9152987821", "Vandrevala: 1860-2662-345", "Aasra: 022-27546669"],
        "delhi":      ["Vandrevala: 1860-2662-345", "NIMHANS Outreach", "iCall: 9152987821"],
        "chennai":    ["Sneha: 044-24640050", "Vandrevala: 1860-2662-345", "iCall: 9152987821"],
        "kolkata":    ["Vandrevala: 1860-2662-345", "iCall: 9152987821"],
        "pune":       ["iCall TISS: 9152987821", "Vandrevala: 1860-2662-345"],
    }

    def get_helplines(self, city: str = "") -> dict:
        """
        Return helplines for a given city plus national helplines.

        Args:
            city: City name (optional)

        Returns:
            dict with national + local helplines and community resources
        """
        city_key = city.strip().lower()
        local = self.CITY_HELPLINES.get(city_key, ["KIRAN: 1800-599-0019 (National)", "Tele-MANAS: 14416", "iCall: 9152987821"])

        return {
            "agent":               "HumanConnectAgent",
            "platform":            "IBM Orchestrate",
            "city":                city or "National",
            "national_helplines":  self.NATIONAL_HELPLINES,
            "local_helplines":     local,
            "community_resources": [
                "Speak with your college counsellor or student welfare officer",
                "Visit your nearest Primary Health Centre (PHC) — free mental health services",
                "Community Health Centres offer counselling in most districts",
                "UGC mandates counselling cells in all colleges",
            ],
            "global": "Find helplines worldwide: findahelpline.org",
            "encouragement": (
                "Reaching out to human support is always the right step. "
                "You deserve care. Contacting a helpline or counsellor early — "
                "before a crisis — is a sign of wisdom and self-compassion."
            ),
        }


# ─────────────────────────────────────────────────────────────────────────────
# Ethics Agent
# HAM Principles: Helpful, Honest, Harmless
# ─────────────────────────────────────────────────────────────────────────────
class EthicsAgent:
    """
    Ethics guardrail applied to all agent outputs.
    HAM Principles: Helpful · Honest · Harmless
    """

    @staticmethod
    def disclaimer() -> str:
        return (
            "⚠️  DISCLAIMER: This system provides mental health AWARENESS and EDUCATIONAL "
            "information ONLY. It does NOT diagnose, treat, or replace professional medical "
            "advice. No personal data is stored. Always consult a qualified mental health "
            "professional for personal concerns. In crisis: KIRAN 1800-599-0019 (24/7, Free)."
        )

    @staticmethod
    def validate(agent_output: dict) -> dict:
        """Append ethics guardrail to any agent output."""
        agent_output["ethics"] = {
            "ham_principles": {"helpful": True, "honest": True, "harmless": True},
            "no_diagnosis": True,
            "no_therapy":   True,
            "data_stored":  False,
            "professional_help_encouraged": True,
        }
        return agent_output


# ─────────────────────────────────────────────────────────────────────────────
# IBM Langflow / IBM Orchestrate Workflow Orchestrator
# ─────────────────────────────────────────────────────────────────────────────
def run_langflow_workflow(
    name:       str = "Friend",
    age:        int = 0,
    city:       str = "",
    journal:    str = "",
    mood_score: int = 5,
    feeling:    str = "",
) -> dict:
    """
    IBM Langflow / IBM Orchestrate Multi-Agent Workflow.

    Orchestration:
      User Input → IBM Orchestrate → Agent1 (Awareness)
                                   → Agent2 (RAG Detection)
                                   → Agent3 (Empathetic)
                                   → Agent4 (Predict/Prevent)
                                   → Agent5 (Human Connect)
                                   → Ethics Guardrail
                                   → Report

    Args:
        name:       User name (optional, with consent)
        age:        User age
        city:       User city
        journal:    Free-form journal text
        mood_score: Self-reported mood 1-10
        feeling:    Expressed feeling for empathetic agent

    Returns:
        dict with all 5 agent outputs + ethics validation
    """
    print("\n" + "="*64)
    print("  MindCare — IBM Langflow / IBM Orchestrate Workflow")
    print("  Agentic AI: Mental Health Awareness & Suicide Prevention")
    print("="*64)
    print(f"  Agents: IBM Granite granite-13b-chat-v2")
    print(f"  Platform: IBM Langflow + IBM Orchestrate")
    print("="*64 + "\n")

    ethics = EthicsAgent()

    # Agent 1: Awareness
    print("[Orchestrate] → Dispatching Agent 1: AwarenessAgent...")
    a1 = AwarenessAgent()
    out1 = ethics.validate(a1.get_resources("all"))
    print(a1.format_output("all"))

    # Agent 2: RAG Early Detection
    print("\n[Orchestrate] → Dispatching Agent 2: EarlyDetectionRAGAgent...")
    a2 = EarlyDetectionRAGAgent()
    out2 = ethics.validate(a2.detect_signals(journal))
    print(f"  Signals detected: {out2.get('signals_detected', [])}")
    print(f"  RAG results: {len(out2.get('rag_results', []))} entries retrieved")

    # Agent 3: Empathetic Support
    print("\n[Orchestrate] → Dispatching Agent 3: EmpatheticSupportAgent...")
    a3 = EmpatheticSupportAgent()
    out3 = ethics.validate(a3.get_empathy_response(feeling or journal or "I need support"))
    print(f"  Response: {out3['response'][:100]}...")

    # Agent 4: Predict & Prevent
    print("\n[Orchestrate] → Dispatching Agent 4: PredictPreventAgent...")
    a4 = PredictPreventAgent()
    out4 = ethics.validate(a4.predict(mood_score, journal))
    print(f"  Forecast: {out4['emoji']} {out4['level']}")
    if out4.get("alert"):
        print(f"  ⚠️  Alert: {out4.get('alert_message', '')}")

    # Agent 5: Human Connect
    print("\n[Orchestrate] → Dispatching Agent 5: HumanConnectAgent...")
    a5 = HumanConnectAgent()
    out5 = ethics.validate(a5.get_helplines(city))
    print(f"  Helplines provided for: {out5['city']}")

    # Compile full result
    result = {
        "timestamp":    datetime.datetime.now().isoformat(),
        "user":         {"name": name, "age": age, "city": city},
        "workflow":     "IBM Langflow + IBM Orchestrate",
        "models":       "IBM Granite granite-13b-chat-v2 + Granite Embeddings",
        "agent1_awareness":        out1,
        "agent2_rag_detection":    out2,
        "agent3_empathetic":       out3,
        "agent4_predict_prevent":  out4,
        "agent5_human_connect":    out5,
        "global_disclaimer":       EthicsAgent.disclaimer(),
    }

    # Save report
    _save_report(result, name, age, city, mood_score, journal)

    print("\n[Orchestrate] ✅ Workflow complete. Report saved: Mental_Health_Awareness_Report.md")
    return result


def _save_report(result: dict, name: str, age: int, city: str, mood: int, journal: str):
    """Save the workflow output as Mental_Health_Awareness_Report.md"""
    ts   = result["timestamp"]
    out4 = result["agent4_predict_prevent"]
    out2 = result["agent2_rag_detection"]
    out5 = result["agent5_human_connect"]

    md = f"""# Mental Health Awareness Report
## MindCare — Agentic AI for Mental Health Awareness & Suicide Prevention
### IBM Granite + IBM Langflow + IBM Orchestrate

---

**Generated:** {ts}  
**Name:** {name}  
**Age:** {age or 'Not provided'}  
**City:** {city or 'Not provided'}  
**Mood Score:** {mood}/10  
**Journal Provided:** {'Yes (' + str(len(journal)) + ' chars)' if journal else 'No'}

---

## ⚠️ IMPORTANT DISCLAIMER

> This report is for **educational and awareness purposes ONLY**.  
> It does **NOT** constitute a clinical assessment, diagnosis, or medical advice.  
> **In a crisis: KIRAN 1800-599-0019 (24/7, Free, Multilingual)**

---

## 🤖 5-Agent Agentic Workflow Results

### Agent 1 — AwarenessAgent (IBM Granite)
- Provided mindfulness, coping, and self-care resources from knowledge base.

### Agent 2 — EarlyDetectionRAGAgent (IBM Langflow RAG)
- Signals detected: {out2.get('signals_detected', [])}
- RAG entries retrieved: {len(out2.get('rag_results', []))}
- {out2.get('educational_note', '')}

### Agent 3 — EmpatheticSupportAgent (IBM Granite)
- Empathetic response provided. Active listening. Professional help encouraged.

### Agent 4 — PredictPreventAgent (IBM Granite)
- {out4.get('emoji','')} Forecast: **{out4.get('level','')}**
- {out4.get('forecast','')}
- Strategies: {', '.join(out4.get('strategies',[])[:3])}...
{('- ⚠️ Alert: ' + out4.get('alert_message','')) if out4.get('alert') else ''}

### Agent 5 — HumanConnectAgent (IBM Orchestrate)
- City: {out5.get('city','')}
- {out5.get('encouragement','')}

---

## 📞 Crisis Helplines

| Helpline | Number | Availability |
|----------|--------|-------------|
| KIRAN | 1800-599-0019 | 24/7 Free Multilingual |
| Tele-MANAS | 14416 | 24/7 Govt of India |
| Vandrevala | 1860-2662-345 | 24/7 |
| iCall (TISS) | 9152987821 | Weekdays 8am-10pm |
| Emergency | 112 | 24/7 |
| Global | findahelpline.org | - |

---

## ⚖️ Ethics Agent — HAM Principles
- ✅ Helpful · ✅ Honest · ✅ Harmless
- 🔒 No data stored · 🚫 No diagnosis · 👨‍⚕️ Professional help encouraged

---
*IBM Hackathon · Problem Statement No. 2 · IBM Granite + IBM Langflow + IBM Orchestrate*
"""

    report_path = Path(__file__).parent / "Mental_Health_Awareness_Report.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(md)


# ─────────────────────────────────────────────────────────────────────────────
# Entry Point
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    run_langflow_workflow(
        name="Demo User",
        age=22,
        city="Hyderabad",
        journal="I have been feeling very tired lately and not sleeping well. Sometimes I feel like withdrawing from everyone.",
        mood_score=4,
        feeling="stressed and anxious",
    )
