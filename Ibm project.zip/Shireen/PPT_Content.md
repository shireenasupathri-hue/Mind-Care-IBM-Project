# PPT Content — MindCare: Agentic AI for Mental Health Awareness & Suicide Prevention
## IBM Hackathon | Problem Statement No. 2 | 12 Slides

---

## SLIDE 1 — TITLE SLIDE

**Title:** MindCare
**Subtitle:** Agentic AI for Mental Health Awareness & Suicide Prevention

**Tagline:** *"Awareness Today. Prevention Tomorrow. Powered by IBM."*

**Powered by:**
- IBM Granite Models (granite-13b-chat-v2)
- IBM Langflow (Workflow Orchestration)
- IBM Orchestrate (Multi-Agent Coordination)

**Badges:**
🧠 Agentic AI | 🌐 IBM watsonx.ai | ⚖️ HAM Principles | 🔒 Privacy-First

**Crisis:** KIRAN 1800-599-0019 | Tele-MANAS 14416 | Emergency 112

---

## SLIDE 2 — THE CHALLENGE

**Title:** The Mental Health Crisis in India — Why This Matters Now

**Key Statistics:**
- 🌍 **1 in 4 people** globally experience a mental health condition each year *(WHO 2023)*
- 🇮🇳 **>150 million Indians** need mental health care — only 9,000 psychiatrists available
- 📉 **Doctor ratio:** 1 psychiatrist per 100,000 people in many Indian states *(NIMHANS)*
- ⚠️ Suicide is the **#1 cause of death** among Indians aged 15–29 *(NCRB 2022)*
- 🏫 **71% of college students** report significant levels of stress *(ASSOCHAM India)*
- 🔇 **80% of cases** go untreated due to stigma, unawareness, and access barriers

**The Gap:**
> Millions need support. Professionals are scarce. Stigma silences. Technology can bridge the gap — if designed ethically.

**Visual Suggestion:** Map of India with data overlays | Split: Need vs Available Care

---

## SLIDE 3 — OUR SOLUTION: 5 OBJECTIVES

**Title:** MindCare — 5-Objective Agentic Solution

**Intro:** MindCare is a 5-agent AI system built on IBM Granite + IBM Langflow that addresses mental health through a complete, ethical pipeline.

| # | Objective | Agent | Technology |
|---|-----------|-------|-----------|
| 1 | Promote Awareness & Education | AwarenessAgent | IBM Granite |
| 2 | Enable Early Detection (RAG) | EarlyDetectionRAGAgent | IBM Langflow RAG |
| 3 | Provide Empathetic Support | EmpatheticSupportAgent | IBM Granite |
| 4 | Predict & Prevent Risks | PredictPreventAgent | IBM Granite |
| 5 | Connect to Human Support | HumanConnectAgent | IBM Orchestrate |

**Ethics Guardrail:** EthicsAgent — HAM Principles applied to ALL outputs

**Core Promise:**
> ✅ Awareness-only · 🚫 No Diagnosis · 👨‍⚕️ Always Encourage Professionals · 🔒 No Data Stored

---

## SLIDE 4 — ARCHITECTURE: IBM LANGFLOW WORKFLOW

**Title:** System Architecture — IBM Langflow + IBM Orchestrate

**Architecture Diagram (Text):**

```
┌────────────────────────────────────────────────────────┐
│                    USER INPUT                          │
│  Name (opt) | Age | City | Journal | Mood Scale 1-10  │
└─────────────────────┬──────────────────────────────────┘
                      │
                      ▼
┌────────────────────────────────────────────────────────┐
│           IBM ORCHESTRATE — Workflow Controller        │
│         Routes inputs to appropriate agents            │
└──┬──────────┬──────────┬──────────┬────────────────────┘
   │          │          │          │          │
   ▼          ▼          ▼          ▼          ▼
Agent 1    Agent 2    Agent 3    Agent 4    Agent 5
Awareness  RAG        Empathy    Predict    Human
IBM        IBM        IBM        IBM        IBM
Granite    Langflow   Granite    Granite    Orchestrate
           RAG
   │          │          │          │          │
   └──────────┴──────────┴──────────┴──────────┘
                      │
                      ▼
           ┌──────────────────┐
           │  Ethics Agent    │
           │  HAM Guardrail   │
           └────────┬─────────┘
                    │
                    ▼
        Mental_Health_Awareness_Report.md
```

**Tech Stack Icons:** IBM watsonx.ai | IBM Langflow | IBM Orchestrate | IBM Granite

**Key Design Principle:** Every agent output passes through the Ethics Agent guardrail before delivery.

---

## SLIDE 5 — AGENT 1: AWARENESS & EDUCATION

**Title:** Agent 1 — AwarenessAgent
**Subtitle:** Promote Mental Health Awareness & Education

**Model:** IBM Granite granite-13b-chat-v2 via IBM watsonx.ai

**What It Does:**
Retrieves and presents evidence-based mental health awareness content from the curated knowledge base, personalised to user topic.

**Content Delivered:**

🌬️ **Mindfulness Techniques**
- 4-7-8 Breathing, Box Breathing (4-4-4-4)
- 5-4-3-2-1 Grounding, Body Scan, Mindful Walking

🛡️ **Coping Strategies**
- Talk to trusted person, Expressive journaling
- Walking in nature, Creative expression, Limit social media

💤 **Self-Care Practices**
- Sleep hygiene (7-9 hrs), Daily routine structure
- 20-20-20 screen breaks, Hydration, Physical activity (150 min/week)

**IBM Langflow Node:** `AwarenessAgent` → `KnowledgeBaseRetriever` → `IBM Granite Chat`

**Code Highlight:**
```python
class AwarenessAgent:
    def get_resources(self, topic: str = "all") -> dict:
        # IBM Granite retrieves from knowledge base
        # Returns: mindfulness + coping + self-care entries
```

**Impact:** Scalable awareness delivery to millions — 24/7, multilingual-ready.

---

## SLIDE 6 — AGENT 2: EARLY DETECTION (RAG)

**Title:** Agent 2 — EarlyDetectionRAGAgent
**Subtitle:** Enable Early Detection via Retrieval-Augmented Generation

**Model:** IBM Granite Embeddings + granite-13b-chat-v2
**Pipeline:** IBM Langflow RAG Pipeline

**RAG Architecture:**
```
User Journal Text
      │
      ▼
IBM Granite Text Embeddings
      │
      ▼
knowledge_base.json → Vector Store (Milvus/Chroma)
      │
      ▼
Cosine Similarity Retrieval (Top-K)
      │
      ▼
IBM Granite Augmented Generation
      │
      ▼
Educational Awareness Response (NOT diagnosis)
```

**Signal Categories (Educational Only):**
- Sleep Changes | Social Withdrawal | Hopelessness Indicators
- Stress Indicators | Low Mood | Appetite Changes

**⚠️ Critical Safeguards:**
- All output is educational information ONLY
- Explicit disclaimer: "NOT a clinical assessment or diagnosis"
- Crisis helplines shown whenever distress signals detected

**Code Highlight:**
```python
class EarlyDetectionRAGAgent:
    def detect_signals(self, journal: str) -> dict:
        retrieved = self._rag_retrieve(journal)  # IBM Langflow RAG
        # Returns educational info, NOT diagnosis
```

**Demo Flow:** Journal: "I haven't been sleeping well and feel withdrawn" → RAG retrieves Sleep Hygiene + Social Support entries

---

## SLIDE 7 — AGENT 3: EMPATHETIC SUPPORT

**Title:** Agent 3 — EmpatheticSupportAgent
**Subtitle:** Provide Empathetic, Active-Listening Support

**Model:** IBM Granite granite-13b-chat-v2

**What It Does:**
A conversational agent that listens actively, validates feelings, and responds with empathy — following evidence-based communication principles.

**Response Principles:**
- 👂 **Active Listening** — Reflect back what the user said
- 💙 **Validation** — "What you're feeling is real and valid"
- 🤝 **Non-Judgment** — Safe, accepting space
- 📢 **Encouragement** — Consistently encourage professional help
- 🆘 **Crisis Awareness** — Detects hopelessness signals, provides KIRAN helpline

**Sample IBM Granite Responses:**

> *"Thank you for sharing that with me. It takes courage to acknowledge these feelings. You are not alone."*

> *"I hear you. Anxiety can feel overwhelming, but naming it is the first step. Try breathing slowly with me..."*

> *"When hope feels distant, that is often a sign that support is needed. Please call KIRAN 1800-599-0019."*

**⚠️ Disclaimer (shown in UI):**
> "I am an AI assistant, not a human counsellor. I am NOT a substitute for professional mental health advice. For personal concerns, please consult a qualified professional."

**Code Highlight:**
```python
class EmpatheticSupportAgent:
    def get_empathy_response(self, feeling: str) -> dict:
        # IBM Granite → empathetic response + disclaimer
```

---

## SLIDE 8 — AGENT 4: PREDICT & PREVENT

**Title:** Agent 4 — PredictPreventAgent
**Subtitle:** Predict Stress Awareness Level & Prevent with Strategies

**Model:** IBM Granite granite-13b-chat-v2

**Input Signals:**
- Self-reported Mood Score (1–10 slider)
- Journal text length and content patterns

**Forecast Levels:**

| Level | Mood | Description | Action |
|-------|------|-------------|--------|
| 🟢 Low | 7–10 | Positive state, maintain habits | Continue wellness practices |
| 🟡 Moderate | 4–6 | Some stress signals | Proactive self-care |
| 🟠 Needs Attention | 1–3 | Elevated signals | Seek human support |

**Preventive Strategies Examples:**
- 🟢: Gratitude journaling, maintain sleep schedule, social connections
- 🟡: 10-min walk, grounding technique, reach out to trusted person
- 🟠: Call KIRAN, speak with counsellor, box breathing, avoid isolation

**Consent-Based Alert (for Needs Attention level):**
> *"If low mood persists, please consider telling a trusted person or healthcare professional. Seeking help is strength. Call KIRAN 1800-599-0019."*

**⚠️ Disclaimer:** Not a clinical risk assessment. Not a diagnosis.

**Code Highlight:**
```python
class PredictPreventAgent:
    def predict(self, mood_score: int, journal: str = "") -> dict:
        # Returns: level + forecast + strategies + alert (if needed)
```

---

## SLIDE 9 — AGENT 5: HUMAN CONNECT

**Title:** Agent 5 — HumanConnectAgent
**Subtitle:** Connect to Human Support — The Most Important Step

**Platform:** IBM Orchestrate

**What It Does:**
Proactively connects users to verified, city-specific human support resources — because AI is a bridge, not a destination.

**National Helplines (Always Available):**

| Helpline | Number | Availability |
|----------|--------|-------------|
| KIRAN | 1800-599-0019 | 24/7 Free Multilingual |
| Tele-MANAS | 14416 | 24/7 Govt of India |
| Vandrevala | 1860-2662-345 | 24/7 |
| iCall TISS | 9152987821 | Weekdays 8am-10pm |
| Sneha India | 044-24640050 | 24/7 |
| Emergency | 112 | 24/7 |

**City-Specific Support (Dynamic):**
Hyderabad → NIMHANS Outreach, Roshni, Erragadda Hospital  
Mumbai → iCall TISS, Aasra, Vandrevala  
Delhi → Vandrevala, iCall  
*(All major Indian cities supported)*

**Community Resources:**
- College counsellors (UGC-mandated in all colleges)
- Primary Health Centres (PHCs) — free services
- Community Health Centres

**Key Message:**
> *"Reaching out to human support is always the right step. You deserve care. Contacting a helpline early — before a crisis — is wisdom and self-compassion."*

---

## SLIDE 10 — TECH STACK

**Title:** Technology Stack — Built on IBM's AI Ecosystem

**Core IBM Technologies:**

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Foundation Model | IBM Granite granite-13b-chat-v2 | Responses, empathy, forecasting |
| Embeddings | IBM Granite Text Embeddings | RAG vector search |
| Workflow | IBM Langflow | Visual AI pipeline orchestration |
| Multi-Agent | IBM Orchestrate | Agent coordination & routing |
| Platform | IBM watsonx.ai | Model hosting & inference |
| Vector Store | Milvus / Chroma (IBM Langflow) | Knowledge base retrieval |

**Application Stack:**

| Component | Technology |
|-----------|-----------|
| Frontend | HTML5 + CSS3 + Vanilla JS |
| Backend | Python 3.8+ (agents.py) |
| Knowledge Base | JSON (knowledge_base.json, 20 entries) |
| Report Output | Markdown (.md) |
| Deployment | IBM Cloud / Local |

**IBM Langflow Pipeline:**
```
Input → IBM Orchestrate Router
     → Granite Chat (Agents 1,3,4)
     → Granite Embeddings → Vector Store → Granite RAG (Agent 2)
     → IBM Orchestrate Connector (Agent 5)
     → Ethics Guardrail → Output
```

**Why IBM Granite?**
- Open-source foundation, enterprise-grade safety
- Strong multilingual capabilities (India-ready)
- Optimised for instruction-following and empathetic dialogue
- watsonx.ai guardrails align with HAM principles

---

## SLIDE 11 — ETHICS, HAM PRINCIPLES & DEMO SCREENSHOTS

**Title:** Ethics Agent — HAM Principles & Safety Guardrails

**HAM Framework:**

| Principle | What It Means | How Implemented |
|-----------|--------------|----------------|
| ✅ **Helpful** | Provide real value | Evidence-based content from curated KB |
| ✅ **Honest** | Transparent about limitations | AI clearly labelled; disclaimers on all outputs |
| ✅ **Harmless** | First, do no harm | No diagnosis; no harmful advice; crisis resources |

**Ethics Agent Guardrails (Applied to ALL 5 Agents):**
- 🚫 No clinical diagnosis or medical advice
- 🚫 No therapeutic claims
- 🔒 No data stored or transmitted externally
- 📢 Crisis helplines always prominent (fixed red banner)
- 👨‍⚕️ Professional help encouraged in every interaction
- 📋 Consent required before personal data fields activate
- 🌐 Follows WHO Safe Messaging Guidelines for suicide prevention

**Code Highlight:**
```python
class EthicsAgent:
    @staticmethod
    def disclaimer() -> str:
        return "AWARENESS ONLY. Not diagnosis. Not therapy. KIRAN: 1800-599-0019"

    @staticmethod
    def validate(agent_output: dict) -> dict:
        # Appends HAM compliance flags to every agent output
```

**Screenshots:**
- [Screenshot 1: Fixed Crisis Banner prominently displayed]
- [Screenshot 2: Agent cards with awareness content]
- [Screenshot 3: RAG detection with educational disclaimer]
- [Screenshot 4: Empathetic chat with IBM Granite responses]
- [Screenshot 5: Mood forecast with preventive strategies]
- [Screenshot 6: Helpline connect page]
- [Screenshot 7: Generated report download]

---

## SLIDE 12 — THANK YOU & FUTURE SCOPE

**Title:** Thank You
**Subtitle:** MindCare — Agentic AI for Mental Health Awareness & Suicide Prevention

**Core Value Proposition:**
> MindCare demonstrates that IBM Granite + IBM Langflow + IBM Orchestrate can be combined to build ethical, scalable, and genuinely helpful AI systems for mental health — one of society's most urgent challenges.

**What We Built:**
✅ 5-agent agentic system on IBM Granite + IBM Langflow  
✅ RAG pipeline from knowledge_base.json  
✅ Empathetic conversational AI with IBM Granite  
✅ Stress awareness forecasting with preventive strategies  
✅ Verified national + city helpline integration  
✅ Ethics guardrail with HAM principles  
✅ Downloadable awareness report  

**Future Scope:**

| Phase | Feature | Impact |
|-------|---------|--------|
| Phase 2 | Telugu + Hindi language support | 300M+ additional users |
| Phase 2 | WhatsApp Bot (IBM Orchestrate + Twilio) | Reach users on familiar platforms |
| Phase 3 | Voice interface for low-literacy access | Rural India accessibility |
| Phase 3 | Direct PHC referral pathway | Healthcare system integration |
| Phase 4 | Peer support community (moderated) | Social connection at scale |
| Phase 4 | Crisis escalation to human counsellors | Real-time intervention |

**Telugu సందేశం (Message):**
> *మానసిక ఆరోగ్యం గురించి మాట్లాడడం ధైర్యం. సహాయం అడగడం బలహీనత కాదు — అది వివేకం.*  
> *Speaking about mental health takes courage. Seeking help is not weakness — it is wisdom.*

---

**Crisis Helplines:**
🆘 KIRAN: **1800-599-0019** | Tele-MANAS: **14416** | Emergency: **112**  
Vandrevala: **1860-2662-345** | iCall: **9152987821** | findahelpline.org

---

*IBM Hackathon 2024 | Problem Statement No. 2 | Built with IBM Granite + IBM Langflow + IBM Orchestrate*  
*"Technology in service of human dignity."*
