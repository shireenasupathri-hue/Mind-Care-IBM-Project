# MindCare — Agentic AI for Mental Health Awareness & Suicide Prevention

> **IBM Hackathon | Problem Statement No. 2**  
> **Team Project | Agentic AI for Social Good**

---

## 🆘 Crisis Helplines — Always Visible

| Helpline | Number | Availability |
|----------|--------|-------------|
| **KIRAN** | **1800-599-0019** | 24/7 Free Multilingual (Govt of India) |
| **Tele-MANAS** | **14416** | 24/7 Govt of India |
| **Vandrevala Foundation** | **1860-2662-345** | 24/7 |
| **iCall (TISS)** | **9152987821** | Weekdays 8am–10pm |
| **Emergency** | **112** | 24/7 |
| **Global** | findahelpline.org | Worldwide |

---

## 🧩 Challenge

Mental health remains one of the most under-addressed public health challenges in India and globally:

- **1 in 4 people** globally will experience a mental health condition each year *(WHO 2023)*
- India has **>150 million** people needing mental health care, with a critical shortage of professionals
- The **doctor-to-patient ratio** for psychiatry is 1:100,000 in many Indian states
- Suicide is the **leading cause of death** among Indians aged 15–29 *(NCRB 2022)*
- **Stigma, lack of awareness, and access barriers** prevent early help-seeking
- Students and youth are disproportionately affected — academic pressure, social isolation, digital overload

There is an urgent need for scalable, ethical, AI-powered systems that can **raise awareness**, **enable early detection**, **provide empathetic support**, and **connect people to human help** — without replacing professional care.

---

## 🎯 5 Objectives (from Problem Statement)

1. **Promote Awareness & Education** — Deliver evidence-based mental health awareness resources (mindfulness, coping strategies, self-care) to users at scale using AI
2. **Enable Early Detection** — Use RAG (Retrieval-Augmented Generation) to identify educational stress signals in user journal text and surface relevant awareness information — for education ONLY, not diagnosis
3. **Provide Empathetic Support** — Offer a compassionate, non-judgmental conversational interface powered by IBM Granite that listens actively, validates feelings, and encourages professional help
4. **Predict & Prevent Risks** — Based on self-reported mood and journal data, provide a stress awareness forecast (Low / Moderate / Needs Attention) and preventive strategies with consent-based alerts
5. **Connect to Human Support** — Proactively connect users to national helplines, city-specific counsellors, college resources, and PHCs — encouraging timely human support

---

## 🏗️ Architecture

### IBM Langflow / IBM Orchestrate Workflow

```
User Input (Name, Age, City, Journal, Mood 1-10)
        │
        ▼
IBM Orchestrate — Workflow Orchestrator
        │
        ├──► Agent 1: AwarenessAgent ──────────────── IBM Granite granite-13b-chat-v2
        │         └─ Knowledge Base → Mindfulness, Coping, Self-Care
        │
        ├──► Agent 2: EarlyDetectionRAGAgent ──────── IBM Langflow RAG Pipeline
        │         └─ Journal → IBM Granite Embeddings → knowledge_base.json
        │              → Vector Retrieval → Augmented Generation (Education Only)
        │
        ├──► Agent 3: EmpatheticSupportAgent ──────── IBM Granite granite-13b-chat-v2
        │         └─ Feeling/Journal → Empathetic Response Templates + LLM
        │
        ├──► Agent 4: PredictPreventAgent ─────────── IBM Granite granite-13b-chat-v2
        │         └─ Mood Score + Journal → Forecast (Low/Moderate/Needs Attention)
        │              → Preventive Strategies → Consent-based Alert
        │
        └──► Agent 5: HumanConnectAgent ────────────── IBM Orchestrate
                  └─ City → National + Local Helplines + PHC + College Counsellor
        │
        ▼
Ethics Agent Guardrail (HAM Principles: Helpful · Honest · Harmless)
        │
        ▼
Mental_Health_Awareness_Report.md
```

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| **LLM / Foundation Model** | IBM Granite `granite-13b-chat-v2` via IBM watsonx.ai |
| **Embeddings (RAG)** | IBM Granite Text Embeddings |
| **Workflow Orchestration** | IBM Langflow (visual AI pipeline builder) |
| **Multi-Agent Coordination** | IBM Orchestrate |
| **Vector Store (RAG)** | IBM Langflow built-in / Chroma / Milvus |
| **Knowledge Base** | `knowledge_base.json` (20 entries, 4 categories) |
| **Frontend** | HTML5 + Vanilla JS (no framework dependencies) |
| **Backend Agents** | Python 3.8+ (`agents.py`) |
| **Report Generation** | Markdown (`.md`) |

---

## 🚀 How to Run

### Prerequisites
```bash
python 3.8+
# No external dependencies required for local simulation
# For IBM watsonx.ai integration: pip install ibm-watsonx-ai langflow
```

### Run the Python Agent System
```bash
cd <project-folder>
python agents.py
```
This runs the full 5-agent IBM Langflow workflow and saves `Mental_Health_Awareness_Report.md`.

### Run the Web Application
```bash
# Option 1: Direct browser open
start index.html          # Windows
open index.html           # macOS

# Option 2: Local server
python -m http.server 8080
# Then open http://localhost:8080
```

### IBM Langflow Integration (Production)
```bash
pip install langflow
langflow run
# Import the workflow: Upload agents.py logic to Langflow visual editor
# Connect IBM watsonx.ai node with your API key
```

### IBM watsonx.ai Configuration
```python
from ibm_watsonx_ai.foundation_models import Model

model = Model(
    model_id="ibm/granite-13b-chat-v2",
    credentials={"url": "https://us-south.ml.cloud.ibm.com", "apikey": "YOUR_API_KEY"},
    project_id="YOUR_PROJECT_ID",
    params={"max_new_tokens": 500, "temperature": 0.7}
)
```

---

## ⚖️ Ethics, Safety & HAM Principles

| Principle | Implementation |
|-----------|---------------|
| ✅ **Helpful** | Evidence-based awareness content from curated knowledge base |
| ✅ **Honest** | All AI responses clearly labelled; limitations explicitly disclosed |
| ✅ **Harmless** | No diagnosis; no therapy claims; crisis resources always prominent |
| 🔒 **Privacy** | No data stored or transmitted; consent-gated personal fields |
| 🚫 **No Diagnosis** | All agents include explicit educational-only disclaimers |
| 👨‍⚕️ **Professional Help** | Every agent output encourages qualified professional consultation |
| 📢 **Safe Messaging** | Follows WHO/AFSP suicide prevention safe messaging guidelines |

### Safe Messaging Guidelines (WHO)
- Crisis helplines prominently displayed at all times (fixed banner)
- No graphic descriptions of methods
- Empathy-first, non-judgmental language
- Consistent encouragement to seek human support

---

## 📁 File Structure

```
./
├── index.html                          ← Frontend (5-Agent Web App)
├── agents.py                           ← Python 5-Agent System (IBM Langflow)
├── knowledge_base.json                 ← 20-entry knowledge base (4 categories)
├── README.md                           ← This file
├── PPT_Content.md                      ← 12-slide presentation content
└── Mental_Health_Awareness_Report.md   ← Generated on workflow run
```

---

## 🔮 Future Scope (Telugu సందేశం)

**తెలుగు సమాజానికి:** మానసిక ఆరోగ్యం గురించి మాట్లాడడం ధైర్యం. సహాయం అడగడం బలహీనత కాదు — అది వివేకం.

**English Translation:** To Telugu society: Speaking about mental health takes courage. Seeking help is not weakness — it is wisdom.

### Planned Enhancements
1. **Telugu Language Support** — Full regional language interface for Andhra Pradesh / Telangana
2. **Voice Interface** — Speech-to-text journaling for low-literacy accessibility
3. **College Integration** — Direct API connection to UGC-mandated counselling portals
4. **WhatsApp Bot** — Reach users on familiar platforms via IBM Orchestrate + Twilio
5. **Longitudinal Tracking** — Consent-based mood trend analysis over weeks (privacy-preserving)
6. **PHC Integration** — Direct referral pathway to nearest Primary Health Centre
7. **Peer Support Network** — Moderated, anonymous community boards
8. **Crisis Escalation Protocol** — Automated handoff to human counsellors when high-risk signals detected

---

## 👥 Acknowledgements

- **IBM watsonx.ai** — IBM Granite foundation models
- **IBM Langflow** — Visual AI workflow orchestration
- **IBM Orchestrate** — Multi-agent coordination
- **NIMHANS** — Clinical guidelines reference
- **WHO Mental Health Action Plan 2013-2030** — Framework reference
- **KIRAN Helpline** — Ministry of Social Justice & Empowerment, Govt of India

---

*Built with ❤️ for mental health awareness | IBM Hackathon 2024 | Problem Statement No. 2*
